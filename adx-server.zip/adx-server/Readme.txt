  ______    ___    ______           ___     ____    _  __
 /_  __/   /   |  / ____/          /   |   / __ \  | |/ /
  / /     / /| | / /      ______  / /| |  / / / /  |   / 
 / /     / ___ |/ /___   /_____/ / ___ | / /_/ /  /   |  
/_/     /_/  |_|\____/          /_/  |_|/_____/  /_/|_|  
                                                         
                                                         
This folder contains all needed code and executables to run the	ADX server.

How to run the server:
	1. To run the server, start the "runServer.sh" executable.
	2. The server will start automatically and will wait for connections to start games.
	
How to configure the server:
	1. After the server is started, it generates a web site, acessible via "http://localhost:8080/"
	   Its initial username and password are 'admin'/'admin'.
	2. In the web site you will find:
		2.1 User configuration controls
		2.2 Game configuration controls
		2.3 Online game viewer, acessible via "http://localhost:8080/localhost/viewer/"
		                           